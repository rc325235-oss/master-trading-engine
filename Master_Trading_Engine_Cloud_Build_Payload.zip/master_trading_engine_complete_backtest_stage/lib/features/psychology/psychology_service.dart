class PsychologyAssessment {
  final double trapRisk;
  final double buyerPressure;
  final double sellerPressure;
  const PsychologyAssessment({required this.trapRisk, required this.buyerPressure, required this.sellerPressure});
}
