import 'backtest_models.dart';
import '../../core/domain/trading_signal.dart';
import 'realistic_backtest_calculator.dart';
import 'realistic_backtest_models.dart';

class TradeLifecycleConfig {
  final double stopLossPercent;
  final double targetPercent;
  final BacktestCosts costs;

  const TradeLifecycleConfig({
    this.stopLossPercent = 0.01,
    this.targetPercent = 0.02,
    this.costs = const BacktestCosts(),
  });
}

class EquityPoint {
  final DateTime time;
  final double equity;
  final double drawdown;

  const EquityPoint({
    required this.time,
    required this.equity,
    required this.drawdown,
  });
}

class LifecycleResult {
  final BacktestTrade trade;
  final RealisticTradeResult execution;

  const LifecycleResult({
    required this.trade,
    required this.execution,
  });
}

class TradeLifecycle {
  final RealisticBacktestCalculator calculator;
  final TradeLifecycleConfig config;

  const TradeLifecycle({
    this.calculator = const RealisticBacktestCalculator(),
    this.config = const TradeLifecycleConfig(),
  });

  bool stopHit({
    required double entry,
    required double price,
    required bool isLong,
  }) {
    final stop = isLong
        ? entry * (1 - config.stopLossPercent)
        : entry * (1 + config.stopLossPercent);
    return isLong ? price <= stop : price >= stop;
  }

  bool targetHit({
    required double entry,
    required double price,
    required bool isLong,
  }) {
    final target = isLong
        ? entry * (1 + config.targetPercent)
        : entry * (1 - config.targetPercent);
    return isLong ? price >= target : price <= target;
  }

  LifecycleResult close({
    required String symbol,
    required SignalDirection direction,
    required DateTime entryTime,
    required DateTime exitTime,
    required double entryPrice,
    required double exitPrice,
    required double quantity,
    String exitReason = 'unknown',
  }) {
    final isLong = direction == SignalDirection.buy;
    final execution = calculator.closeTrade(
      entryPrice: entryPrice,
      exitPrice: exitPrice,
      quantity: quantity,
      isLong: isLong,
      costs: config.costs,
    );

    return LifecycleResult(
      trade: BacktestTrade(
        symbol: symbol,
        direction: direction,
        entryTime: entryTime,
        exitTime: exitTime,
        entryPrice: entryPrice,
        exitPrice: exitPrice,
        pnl: execution.netPnl,
        exitReason: exitReason,
      ),
      execution: execution,
    );
  }
}

