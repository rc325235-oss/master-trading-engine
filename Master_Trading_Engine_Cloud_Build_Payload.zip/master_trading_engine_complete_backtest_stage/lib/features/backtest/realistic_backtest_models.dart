class BacktestCosts {
  final double brokeragePerTrade;
  final double slippageBps;
  final double feeRate;

  const BacktestCosts({
    this.brokeragePerTrade = 0,
    this.slippageBps = 0,
    this.feeRate = 0,
  });
}

class BacktestPositionSizing {
  final double capital;
  final double riskPerTrade;
  final double maxPositionValue;

  const BacktestPositionSizing({
    required this.capital,
    this.riskPerTrade = 0.01,
    this.maxPositionValue = double.infinity,
  });
}

class RealisticTradeResult {
  final double grossPnl;
  final double costs;
  final double netPnl;
  final double entryFill;
  final double exitFill;
  final double quantity;

  const RealisticTradeResult({
    required this.grossPnl,
    required this.costs,
    required this.netPnl,
    required this.entryFill,
    required this.exitFill,
    required this.quantity,
  });
}
