import '../../core/domain/models/market_models.dart';
import '../../core/domain/trading_signal.dart';

class HistoricalBar {
  final DateTime timestamp;
  final double open;
  final double high;
  final double low;
  final double close;
  final double volume;

  const HistoricalBar({
    required this.timestamp,
    required this.open,
    required this.high,
    required this.low,
    required this.close,
    this.volume = 0,
  });

  MarketTick toTick(String symbol) => MarketTick(
        symbol: symbol,
        price: close,
        timestamp: timestamp,
        isStale: false,
      );
}

class BacktestTrade {
  final String symbol;
  final SignalDirection direction;
  final DateTime entryTime;
  final DateTime exitTime;
  final double entryPrice;
  final double exitPrice;
  final double pnl;
  final String exitReason;

  const BacktestTrade({
    required this.symbol,
    required this.direction,
    required this.entryTime,
    required this.exitTime,
    required this.entryPrice,
    required this.exitPrice,
    required this.pnl,
    this.exitReason = 'unknown',
  });
}

class BacktestReport {
  final int bars;
  final int trades;
  final int wins;
  final int losses;
  final double netPnl;
  final double winRate;
  final double maxDrawdown;

  const BacktestReport({
    required this.bars,
    required this.trades,
    required this.wins,
    required this.losses,
    required this.netPnl,
    required this.winRate,
    required this.maxDrawdown,
  });
}


class EquityPoint {
  final DateTime time;
  final double equity;
  final double drawdown;

  const EquityPoint({
    required this.time,
    required this.equity,
    required this.drawdown,
  });
}
