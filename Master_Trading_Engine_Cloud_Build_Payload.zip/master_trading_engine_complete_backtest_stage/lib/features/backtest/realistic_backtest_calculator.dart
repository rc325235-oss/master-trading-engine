import 'realistic_backtest_models.dart';

class RealisticBacktestCalculator {
  const RealisticBacktestCalculator();

  RealisticTradeResult closeTrade({
    required double entryPrice,
    required double exitPrice,
    required double quantity,
    required bool isLong,
    BacktestCosts costs = const BacktestCosts(),
  }) {
    final entryFill = _applySlippage(entryPrice, costs.slippageBps, isLong);
    final exitFill = _applySlippage(exitPrice, costs.slippageBps, !isLong);

    final gross = isLong
        ? (exitFill - entryFill) * quantity
        : (entryFill - exitFill) * quantity;

    final notional = (entryFill + exitFill).abs() * quantity;
    final fees = costs.brokeragePerTrade * 2 + notional * costs.feeRate;

    return RealisticTradeResult(
      grossPnl: gross,
      costs: fees,
      netPnl: gross - fees,
      entryFill: entryFill,
      exitFill: exitFill,
      quantity: quantity,
    );
  }

  double sizePosition({
    required double capital,
    required double entryPrice,
    required double stopPrice,
    double riskPerTrade = 0.01,
    double maxPositionValue = double.infinity,
  }) {
    if (capital <= 0 || entryPrice <= 0 || stopPrice <= 0) return 0;

    final riskAmount = capital * riskPerTrade;
    final perUnitRisk = (entryPrice - stopPrice).abs();
    if (perUnitRisk <= 0) return 0;

    final byRisk = riskAmount / perUnitRisk;
    final byCapital = maxPositionValue == double.infinity
        ? double.infinity
        : maxPositionValue / entryPrice;

    return byRisk < byCapital ? byRisk : byCapital;
  }

  double _applySlippage(double price, double bps, bool adverseForBuy) {
    final adjustment = price * bps / 10000;
    return adverseForBuy ? price + adjustment : price - adjustment;
  }
}
