import '../../core/domain/trading_engine.dart';
import '../../core/domain/trading_signal.dart';
import '../strategy/strategy_models.dart';
import 'backtest_models.dart';
import 'trade_lifecycle.dart';
import 'realistic_backtest_models.dart';

class BacktestEngine {
  final TradingEngine engine;
  final TradeLifecycle lifecycle;

  const BacktestEngine(
    this.engine, {
    this.lifecycle = const TradeLifecycle(),
  });

  BacktestRunResult runDetailed({
    required String symbol,
    required List<HistoricalBar> bars,
    double initialCapital = 100000,
    double quantity = 1,
  }) {
    if (bars.isEmpty) {
      return BacktestRunResult.empty(initialCapital);
    }

    final trades = <BacktestTrade>[];
    final equityCurve = <EquityPoint>[];
    final prices = <double>[];

    double realizedPnl = 0;
    double peakEquity = initialCapital;
    double maxDrawdown = 0;
    double? entryPrice;
    DateTime? entryTime;
    SignalDirection? direction;

    void recordEquity(DateTime time, double equity) {
      if (equity > peakEquity) peakEquity = equity;
      final dd = peakEquity - equity;
      if (dd > maxDrawdown) maxDrawdown = dd;
      equityCurve.add(
        EquityPoint(time: time, equity: equity, drawdown: dd),
      );
    }

    for (var i = 0; i < bars.length; i++) {
      final bar = bars[i];
      prices.add(bar.close);

      final result = engine.evaluate(
        bar.toTick(symbol),
        recentPrices: prices.length > 20
            ? prices.sublist(prices.length - 20)
            : List<double>.from(prices),
      );

      if (entryPrice == null &&
          result.riskAllowed &&
          result.signal.direction != SignalDirection.neutral) {
        entryPrice = bar.close;
        entryTime = bar.timestamp;
        direction = result.signal.direction;
        recordEquity(bar.timestamp, initialCapital + realizedPnl);
        continue;
      }

      if (entryPrice != null && entryTime != null && direction != null) {
        final isLong = direction == SignalDirection.buy;
        final stop = lifecycle.stopHit(
          entry: entryPrice,
          price: bar.close,
          isLong: isLong,
        );
        final target = lifecycle.targetHit(
          entry: entryPrice,
          price: bar.close,
          isLong: isLong,
        );
        final reversal = result.signal.direction != SignalDirection.neutral &&
            result.signal.direction != direction;
        final lastBar = i == bars.length - 1;

        if (stop || target || reversal || lastBar) {
          final closed = lifecycle.close(
            symbol: symbol,
            direction: direction,
            entryTime: entryTime,
            exitTime: bar.timestamp,
            entryPrice: entryPrice,
            exitPrice: bar.close,
            quantity: quantity,
            exitReason: stop ? 'stop_loss' : target ? 'target' : reversal ? 'reversal' : 'end_of_data',
          );

          trades.add(closed.trade);
          realizedPnl += closed.execution.netPnl;
          recordEquity(
            bar.timestamp,
            initialCapital + realizedPnl,
          );

          entryPrice = null;
          entryTime = null;
          direction = null;
        } else {
          final unrealized = isLong
              ? (bar.close - entryPrice) * quantity
              : (entryPrice - bar.close) * quantity;
          recordEquity(
            bar.timestamp,
            initialCapital + realizedPnl + unrealized,
          );
        }
      } else {
        recordEquity(bar.timestamp, initialCapital + realizedPnl);
      }
    }

    final wins = trades.where((t) => t.pnl > 0).length;
    final losses = trades.where((t) => t.pnl < 0).length;
    final grossProfit = trades
        .where((t) => t.pnl > 0)
        .fold<double>(0, (a, t) => a + t.pnl);
    final grossLoss = trades
        .where((t) => t.pnl < 0)
        .fold<double>(0, (a, t) => a + t.pnl.abs());
    final winRate = trades.isEmpty ? 0.0 : wins / trades.length * 100;
    final profitFactor = grossLoss == 0
        ? (grossProfit > 0 ? double.infinity : 0.0)
        : grossProfit / grossLoss;

    return BacktestRunResult(
      symbol: symbol,
      initialCapital: initialCapital,
      finalCapital: initialCapital + realizedPnl,
      bars: bars.length,
      trades: trades,
      wins: wins,
      losses: losses,
      netPnl: realizedPnl,
      winRate: winRate,
      profitFactor: profitFactor,
      maxDrawdown: maxDrawdown,
      equityCurve: equityCurve,
    );
  }

  BacktestReport run({
    required String symbol,
    required List<HistoricalBar> bars,
  }) {
    final result = runDetailed(symbol: symbol, bars: bars);
    return result.toLegacyReport();
  }
}

class BacktestRunResult {
  final String symbol;
  final double initialCapital;
  final double finalCapital;
  final int bars;
  final List<BacktestTrade> trades;
  final int wins;
  final int losses;
  final double netPnl;
  final double winRate;
  final double profitFactor;
  final double maxDrawdown;
  final List<EquityPoint> equityCurve;

  const BacktestRunResult({
    required this.symbol,
    required this.initialCapital,
    required this.finalCapital,
    required this.bars,
    required this.trades,
    required this.wins,
    required this.losses,
    required this.netPnl,
    required this.winRate,
    required this.profitFactor,
    required this.maxDrawdown,
    required this.equityCurve,
  });

  factory BacktestRunResult.empty(double capital) => BacktestRunResult(
        symbol: '',
        initialCapital: capital,
        finalCapital: capital,
        bars: 0,
        trades: const [],
        wins: 0,
        losses: 0,
        netPnl: 0,
        winRate: 0,
        profitFactor: 0,
        maxDrawdown: 0,
        equityCurve: const [],
      );

  BacktestReport toLegacyReport() => BacktestReport(
        bars: bars,
        trades: trades.length,
        wins: wins,
        losses: losses,
        netPnl: netPnl,
        winRate: winRate,
        maxDrawdown: maxDrawdown,
      );
}
