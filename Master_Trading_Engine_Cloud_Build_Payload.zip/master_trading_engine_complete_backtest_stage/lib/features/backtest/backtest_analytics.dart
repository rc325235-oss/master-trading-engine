import 'dart:math' as math;
import '../../core/domain/trading_signal.dart';
import 'backtest_engine.dart';

class PeriodPnl {
  final String period;
  final double pnl;
  final int trades;
  const PeriodPnl(this.period, this.pnl, this.trades);
}

class BacktestAnalytics {
  final double averageWin;
  final double averageLoss;
  final double riskReward;
  final double expectancy;
  final double largestWin;
  final double largestLoss;
  final int maxConsecutiveWins;
  final int maxConsecutiveLosses;
  final double recoveryFactor;
  final double sharpeStyle;
  final Map<String, int> exitReasons;
  final Map<String, double> directionPnl;
  final List<PeriodPnl> monthly;

  const BacktestAnalytics({
    required this.averageWin,
    required this.averageLoss,
    required this.riskReward,
    required this.expectancy,
    required this.largestWin,
    required this.largestLoss,
    required this.maxConsecutiveWins,
    required this.maxConsecutiveLosses,
    required this.recoveryFactor,
    required this.sharpeStyle,
    required this.exitReasons,
    required this.directionPnl,
    required this.monthly,
  });

  factory BacktestAnalytics.from(BacktestRunResult r) {
    final wins = r.trades.where((t) => t.pnl > 0).toList();
    final losses = r.trades.where((t) => t.pnl < 0).toList();
    final avgWin = wins.isEmpty ? 0 : wins.map((t) => t.pnl).reduce((a,b)=>a+b) / wins.length;
    final avgLossAbs = losses.isEmpty ? 0 : losses.map((t) => t.pnl.abs()).reduce((a,b)=>a+b) / losses.length;
    final rr = avgLossAbs == 0 ? 0 : avgWin / avgLossAbs;
    final expectancy = r.trades.isEmpty ? 0 : r.netPnl / r.trades.length;
    final largestWin = wins.isEmpty ? 0 : wins.map((t)=>t.pnl).reduce(math.max);
    final largestLoss = losses.isEmpty ? 0 : losses.map((t)=>t.pnl).reduce(math.min);
    var cw=0, cl=0, mw=0, ml=0;
    for (final t in r.trades) {
      if (t.pnl > 0) { cw++; cl=0; mw=math.max(mw,cw); }
      else if (t.pnl < 0) { cl++; cw=0; ml=math.max(ml,cl); }
    }
    final recovery = r.maxDrawdown == 0 ? 0 : r.netPnl / r.maxDrawdown;
    final returns = <double>[];
    for (var i=1; i<r.equityCurve.length; i++) {
      final prev=r.equityCurve[i-1].equity;
      if (prev != 0) returns.add((r.equityCurve[i].equity-prev)/prev);
    }
    final mean = returns.isEmpty ? 0 : returns.reduce((a,b)=>a+b)/returns.length;
    final variance = returns.length < 2 ? 0 : returns.map((x)=>(x-mean)*(x-mean)).reduce((a,b)=>a+b)/(returns.length-1);
    final sd=math.sqrt(variance);
    final sharpe=sd==0 ? 0 : mean/sd*math.sqrt(252);
    final reasons=<String,int>{};
    final dir=<String,double>{'buy':0,'sell':0};
    final monthMap=<String,List<BacktestTrade>>{};
    for(final t in r.trades){
      reasons[t.exitReason]=(reasons[t.exitReason]??0)+1;
      final key=t.direction==SignalDirection.buy?'buy':'sell'; dir[key]=(dir[key]??0)+t.pnl;
      final m='${t.exitTime.year}-${t.exitTime.month.toString().padLeft(2,'0')}'; (monthMap[m]??=[]).add(t);
    }
    final monthly=monthMap.entries.toList()..sort((a,b)=>a.key.compareTo(b.key));
    return BacktestAnalytics(averageWin:avgWin,averageLoss:-avgLossAbs,riskReward:rr,expectancy:expectancy,largestWin:largestWin,largestLoss:largestLoss,maxConsecutiveWins:mw,maxConsecutiveLosses:ml,recoveryFactor:recovery,sharpeStyle:sharpe,exitReasons:reasons,directionPnl:dir,monthly:monthly.map((e)=>PeriodPnl(e.key,e.value.fold(0,(s,t)=>s+t.pnl),e.value.length)).toList());
  }
}
