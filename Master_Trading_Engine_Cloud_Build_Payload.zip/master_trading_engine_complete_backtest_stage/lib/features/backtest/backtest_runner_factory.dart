import '../../core/engine/trading_engine.dart';
import '../../features/risk/risk_firewall.dart';
import '../strategy/momentum_strategy.dart';
import 'backtest_engine.dart';
import 'trade_lifecycle.dart';
import 'realistic_backtest_models.dart';

class BacktestRunnerFactory {
  const BacktestRunnerFactory();

  BacktestEngine create({
    double minimumScore = 20,
    double stopLossPercent = 0.01,
    double targetPercent = 0.02,
    double brokeragePerTrade = 20,
    double feeRate = 0.0005,
    double slippageBps = 2,
  }) {
    final engine = TradingEngine(
      config: TradingEngineConfig(
        strategyEnabled: true,
        minimumScore: minimumScore,
        // Historical bars are intentionally allowed through the health gate.
        staleSeconds: 1e15,
      ),
      strategy: const MomentumStrategy(),
      riskFirewall: RiskFirewall(minimumScore: minimumScore),
    );

    return BacktestEngine(
      engine,
      lifecycle: TradeLifecycle(
        config: TradeLifecycleConfig(
          stopLossPercent: stopLossPercent,
          targetPercent: targetPercent,
          costs: BacktestCosts(
            brokeragePerTrade: brokeragePerTrade,
            feeRate: feeRate,
            slippageBps: slippageBps,
          ),
        ),
      ),
    );
  }
}
