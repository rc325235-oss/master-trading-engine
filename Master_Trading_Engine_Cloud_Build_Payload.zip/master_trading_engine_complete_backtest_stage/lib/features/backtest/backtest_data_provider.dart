import 'backtest_models.dart';

abstract interface class HistoricalDataProvider {
  Future<List<HistoricalBar>> load(String source);
}

class CsvHistoricalDataProviderAdapter implements HistoricalDataProvider {
  final Future<List<HistoricalBar>> Function(String source) loader;
  const CsvHistoricalDataProviderAdapter(this.loader);
  @override Future<List<HistoricalBar>> load(String source) => loader(source);
}

class JsonHistoricalDataProviderAdapter implements HistoricalDataProvider {
  final Future<List<HistoricalBar>> Function(String source) loader;
  const JsonHistoricalDataProviderAdapter(this.loader);
  @override Future<List<HistoricalBar>> load(String source) => loader(source);
}
