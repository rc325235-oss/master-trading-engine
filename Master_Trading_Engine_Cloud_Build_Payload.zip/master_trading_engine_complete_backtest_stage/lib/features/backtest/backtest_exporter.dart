import 'dart:convert';
import 'backtest_engine.dart';

class BacktestExporter {
  const BacktestExporter();

  String json(BacktestRunResult r) => const JsonEncoder.withIndent('  ').convert({
    'symbol': r.symbol, 'initialCapital': r.initialCapital, 'finalCapital': r.finalCapital,
    'netPnl': r.netPnl, 'bars': r.bars, 'totalTrades': r.trades.length, 'wins': r.wins,
    'losses': r.losses, 'winRatePercent': r.winRate, 'profitFactor': r.profitFactor.isFinite ? r.profitFactor : null,
    'maxDrawdown': r.maxDrawdown,
    'equityCurve': r.equityCurve.map((p) => {'timestamp': p.time.toIso8601String(), 'equity': p.equity, 'drawdown': p.drawdown}).toList(),
    'trades': r.trades.map((t) => {
      'symbol': t.symbol, 'direction': t.direction.name, 'entryTime': t.entryTime.toIso8601String(),
      'exitTime': t.exitTime.toIso8601String(), 'entryPrice': t.entryPrice, 'exitPrice': t.exitPrice, 'exitReason': t.exitReason, 'netPnl': t.pnl,
    }).toList(),
  });

  String tradesCsv(BacktestRunResult r) {
    final b = StringBuffer('symbol,direction,entryTime,exitTime,entryPrice,exitPrice,exitReason,netPnl\n');
    for (final t in r.trades) {
      b.writeln('${_q(t.symbol)},${t.direction.name},${t.entryTime.toIso8601String()},${t.exitTime.toIso8601String()},${t.entryPrice},${t.exitPrice},${t.exitReason},${t.pnl}');
    }
    return b.toString();
  }
  String _q(String value) => '"${value.replaceAll('"', '""')}"';
}
