import '../../core/domain/models/market_models.dart';

class StrategyContext {
  final MarketTick tick;
  final List<double> recentPrices;

  const StrategyContext({
    required this.tick,
    required this.recentPrices,
  });
}

class StrategyDecision {
  final double score;
  final List<String> reasons;

  const StrategyDecision({
    required this.score,
    required this.reasons,
  });
}

abstract interface class Strategy {
  String get id;
  StrategyDecision evaluate(StrategyContext context);
}
