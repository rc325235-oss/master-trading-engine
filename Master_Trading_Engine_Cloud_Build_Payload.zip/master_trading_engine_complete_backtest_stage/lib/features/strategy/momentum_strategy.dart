import '../../core/domain/trading_signal.dart';
import 'strategy_models.dart';

class MomentumStrategy implements Strategy {
  @override
  String get id => 'momentum_v1';

  @override
  StrategyDecision evaluate(StrategyContext context) {
    final prices = context.recentPrices;
    if (prices.length < 3) {
      return const StrategyDecision(
        score: 0,
        reasons: ['INSUFFICIENT_HISTORY'],
      );
    }

    final a = prices[prices.length - 3];
    final b = prices[prices.length - 2];
    final c = prices.last;

    if (a <= 0 || b <= 0 || c <= 0) {
      return const StrategyDecision(score: 0, reasons: ['INVALID_PRICE']);
    }

    final firstMove = (b - a) / a;
    final secondMove = (c - b) / b;
    final sameDirection = firstMove.sign == secondMove.sign;

    if (!sameDirection) {
      return const StrategyDecision(score: 20, reasons: ['MOMENTUM_MIXED']);
    }

    final magnitude = ((firstMove.abs() + secondMove.abs()) * 10000)
        .clamp(0, 50)
        .toDouble();

    return StrategyDecision(
      score: 20 + magnitude,
      reasons: [
        firstMove > 0 ? 'UP_MOMENTUM' : 'DOWN_MOMENTUM',
        'MOMENTUM_CONFIRMED',
      ],
    );
  }
}
