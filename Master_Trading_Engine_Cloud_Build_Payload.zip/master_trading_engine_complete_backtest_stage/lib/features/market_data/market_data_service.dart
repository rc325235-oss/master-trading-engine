// Phase integration point: market_data
