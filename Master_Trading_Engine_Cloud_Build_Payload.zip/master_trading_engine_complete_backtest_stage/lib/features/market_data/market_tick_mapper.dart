import '../../core/domain/models/market_models.dart';
import 'upstox/upstox_feed_message.dart';

class MarketTickMapper {
  MarketTick fromLtpc(UpstoxFeedMessage message) {
    final sourceTs = message.ltpc.ltt;
    final timestamp = sourceTs == null
        ? DateTime.fromMillisecondsSinceEpoch(message.receivedAtMs)
        : DateTime.fromMillisecondsSinceEpoch(sourceTs);

    return MarketTick(
      symbol: message.instrumentKey,
      price: message.ltpc.ltp,
      timestamp: timestamp,
      isStale: DateTime.now().difference(timestamp).inSeconds > 5,
    );
  }
}
