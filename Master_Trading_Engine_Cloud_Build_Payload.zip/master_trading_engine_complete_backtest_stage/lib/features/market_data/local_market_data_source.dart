import '../../core/domain/models/market_models.dart';
import '../../core/engine/trading_engine.dart';

class LocalMarketDataSource implements MarketDataSource {
  @override
  Future<MarketTick> getLatest(String symbol) async {
    // Deterministic development data only. Not a live feed.
    return MarketTick(
      symbol: symbol,
      price: 100.0,
      timestamp: DateTime.now(),
      isStale: false,
    );
  }
}
