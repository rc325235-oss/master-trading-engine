class MarketDataHealth {
  final bool connected;
  final bool authenticated;
  final bool marketOpen;
  final DateTime? lastTickAt;

  const MarketDataHealth({
    required this.connected,
    required this.authenticated,
    required this.marketOpen,
    this.lastTickAt,
  });

  bool get stale {
    final last = lastTickAt;
    if (last == null) return true;
    return DateTime.now().difference(last).inSeconds > 5;
  }

  bool get tradeAllowed =>
      connected && authenticated && marketOpen && !stale;
}
