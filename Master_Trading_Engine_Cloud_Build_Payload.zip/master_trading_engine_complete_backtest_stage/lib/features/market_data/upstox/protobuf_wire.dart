
import 'dart:typed_data';

class ProtoReader {
  final Uint8List bytes;
  int offset = 0;

  ProtoReader(this.bytes);

  bool get done => offset >= bytes.length;

  int readVarint() {
    var result = 0;
    var shift = 0;
    while (true) {
      if (offset >= bytes.length) {
        throw const FormatException('Truncated protobuf varint');
      }
      final b = bytes[offset++];
      result |= (b & 0x7f) << shift;
      if ((b & 0x80) == 0) return result;
      shift += 7;
      if (shift > 63) {
        throw const FormatException('Invalid protobuf varint');
      }
    }
  }

  Uint8List readBytes() {
    final length = readVarint();
    if (length < 0 || offset + length > bytes.length) {
      throw const FormatException('Truncated protobuf bytes');
    }
    final out = Uint8List.sublistView(bytes, offset, offset + length);
    offset += length;
    return out;
  }

  void skip(int wireType) {
    switch (wireType) {
      case 0:
        readVarint();
        return;
      case 1:
        offset += 8;
        return;
      case 2:
        final length = readVarint();
        offset += length;
        return;
      case 5:
        offset += 4;
        return;
      default:
        throw FormatException('Unsupported protobuf wire type: $wireType');
    }
  }
}

class ProtoField {
  final int number;
  final int wireType;
  final Object value;

  const ProtoField(this.number, this.wireType, this.value);
}

Iterable<ProtoField> readFields(Uint8List bytes) sync* {
  final r = ProtoReader(bytes);
  while (!r.done) {
    final tag = r.readVarint();
    final number = tag >> 3;
    final wire = tag & 7;
    if (wire == 2) {
      yield ProtoField(number, wire, r.readBytes());
    } else if (wire == 0) {
      yield ProtoField(number, wire, r.readVarint());
    } else {
      r.skip(wire);
    }
  }
}

double decodeDouble(Uint8List bytes) {
  final data = ByteData.sublistView(bytes);
  return data.getFloat64(0, Endian.little);
}
