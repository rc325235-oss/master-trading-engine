import '../../../core/domain/models/market_models.dart';
import '../../../core/domain/trading_engine.dart';

class EngineFeedBridge {
  final TradingEngine engine;

  const EngineFeedBridge(this.engine);

  TradingEngineResult process(MarketTick tick) {
    return engine.evaluate(tick);
  }
}
