class UpstoxConfig {
  final String clientId;
  final String redirectUri;
  final String? accessToken;

  const UpstoxConfig({
    required this.clientId,
    required this.redirectUri,
    this.accessToken,
  });

  bool get hasAccessToken =>
      accessToken != null && accessToken!.trim().isNotEmpty;

  static const authorizationBase =
      'https://api.upstox.com/v2/login/authorization/dialog';

  static const marketFeedAuthorizePath =
      '/v3/feed/market-data-feed/authorize';
}
