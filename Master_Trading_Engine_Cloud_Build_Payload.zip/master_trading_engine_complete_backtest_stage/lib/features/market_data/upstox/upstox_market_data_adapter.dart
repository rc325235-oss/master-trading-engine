import 'package:web_socket_channel/web_socket_channel.dart';

import '../../../core/domain/models/market_models.dart';
import 'upstox_auth_service.dart';
import 'upstox_config.dart';

class UpstoxMarketDataAdapter {
  final UpstoxAuthService authService;

  WebSocketChannel? _channel;

  UpstoxMarketDataAdapter({UpstoxAuthService? authService})
      : authService = authService ?? UpstoxAuthService();

  Future<void> connect(UpstoxConfig config) async {
    final uri = await authService.authorizeMarketFeed(config);
    _channel = WebSocketChannel.connect(uri);
  }

  Stream<dynamic> get rawMessages =>
      _channel?.stream ?? const Stream.empty();

  /// V3 subscription messages are binary and use the Upstox protobuf schema.
  /// The protobuf decoder/subscription writer is intentionally isolated here.
  /// No live subscription is performed until the generated proto model is added.
  Future<void> subscribeLtpc(List<String> instrumentKeys) async {
    if (_channel == null) {
      throw StateError('Connect to the authorized market feed first.');
    }
    if (instrumentKeys.isEmpty) {
      throw ArgumentError('At least one instrument key is required.');
    }
    throw UnimplementedError(
      'V3 protobuf subscription encoder is the next implementation step.',
    );
  }

  void dispose() {
    _channel?.sink.close();
    _channel = null;
  }

  MarketTick toMarketTick({
    required String symbol,
    required double ltp,
    required DateTime timestamp,
    bool stale = false,
  }) {
    return MarketTick(
      symbol: symbol,
      price: ltp,
      timestamp: timestamp,
      isStale: stale,
    );
  }
}
