import 'dart:typed_data';

import '../../../core/domain/models/market_models.dart';
import '../market_data_health.dart';
import 'upstox_protobuf_decoder.dart';

class UpstoxLiveFeedPipeline<T> {
  final UpstoxProtobufDecoder<T> decoder;
  final MarketTick Function(T decoded) tickMapper;

  UpstoxLiveFeedPipeline({
    required this.decoder,
    required this.tickMapper,
  });

  MarketTick decodeTick(Uint8List bytes) {
    final decoded = decoder.decode(bytes);
    return tickMapper(decoded);
  }

  bool canFeedEngine(MarketDataHealth health) => health.tradeAllowed;
}
