
import 'dart:typed_data';

import '../../../core/domain/models/market_models.dart';
import 'upstox_binary_feed_decoder.dart';

class MarketTickStreamMapper {
  final UpstoxBinaryFeedDecoder decoder;

  const MarketTickStreamMapper({UpstoxBinaryFeedDecoder? decoder})
      : decoder = decoder ?? const UpstoxBinaryFeedDecoder();

  List<MarketTick> map(Uint8List bytes) {
    final decoded = decoder.decode(bytes);
    return decoded.map((item) {
      final timestamp = item.lttMs == null
          ? DateTime.now()
          : DateTime.fromMillisecondsSinceEpoch(item.lttMs!);
      return MarketTick(
        symbol: item.instrumentKey,
        price: item.ltp,
        timestamp: timestamp,
        isStale: DateTime.now().difference(timestamp).inSeconds > 5,
      );
    }).toList();
  }
}
