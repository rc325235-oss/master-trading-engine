import 'dart:typed_data';

/// Adapter boundary for the generated Upstox V3 protobuf class.
///
/// The generated file is intentionally not hand-written. Run:
///   dart run protoc_plugin:protoc-gen-dart --proto_path=proto --dart_out=lib/generated proto/MarketDataFeed.proto
/// Then implement this adapter using FeedResponse.fromBuffer(bytes).
abstract interface class UpstoxProtobufDecoder<T> {
  T decode(Uint8List bytes);
}
