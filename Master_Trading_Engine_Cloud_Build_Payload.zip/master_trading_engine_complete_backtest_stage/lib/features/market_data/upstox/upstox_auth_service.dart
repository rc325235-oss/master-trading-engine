import 'package:http/http.dart' as http;
import 'upstox_config.dart';

class UpstoxAuthService {
  Uri buildLoginUri(UpstoxConfig config, {String? state}) {
    return Uri.parse(UpstoxConfig.authorizationBase).replace(
      queryParameters: {
        'client_id': config.clientId,
        'redirect_uri': config.redirectUri,
        'response_type': 'code',
        if (state != null) 'state': state,
      },
    );
  }

  Future<Uri> authorizeMarketFeed(UpstoxConfig config) async {
    final token = config.accessToken;
    if (token == null || token.isEmpty) {
      throw StateError('Access token is required for market feed authorization.');
    }

    final response = await http.get(
      Uri.parse('https://api.upstox.com${UpstoxConfig.marketFeedAuthorizePath}'),
      headers: {
        'Authorization': 'Bearer $token',
        'Accept': 'application/json',
      },
    );

    if (response.statusCode < 200 || response.statusCode >= 300) {
      throw StateError(
        'Market feed authorization failed: HTTP ${response.statusCode}',
      );
    }

    // The response contains authorized_redirect_uri. Parsing is deliberately
    // kept behind a small adapter so the rest of the app remains broker-neutral.
    final body = response.body;
    final match = RegExp(r'"authorized_redirect_uri"\s*:\s*"([^"]+)"')
        .firstMatch(body);
    if (match == null) {
      throw StateError('authorized_redirect_uri missing from Upstox response.');
    }

    return Uri.parse(match.group(1)!);
  }
}
