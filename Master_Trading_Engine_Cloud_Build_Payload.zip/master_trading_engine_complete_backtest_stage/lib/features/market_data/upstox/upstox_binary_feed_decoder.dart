
import 'dart:typed_data';

import 'decoded_tick.dart';
import 'protobuf_wire.dart';

class UpstoxBinaryFeedDecoder {
  const UpstoxBinaryFeedDecoder();
  List<DecodedTickCandidate> decode(Uint8List bytes) {
    final output = <DecodedTickCandidate>[];

    for (final responseField in readFields(bytes)) {
      // FeedResponse.feeds = field 2, map<string, Feed>.
      if (responseField.number != 2 || responseField.wireType != 2) {
        continue;
      }

      final entry = responseField.value as Uint8List;
      String? instrument;
      Uint8List? feedBytes;

      for (final entryField in readFields(entry)) {
        if (entryField.number == 1 && entryField.wireType == 2) {
          instrument = String.fromCharCodes(entryField.value as Uint8List);
        } else if (entryField.number == 2 && entryField.wireType == 2) {
          feedBytes = entryField.value as Uint8List;
        }
      }

      if (instrument == null || feedBytes == null) continue;

      final ltpc = _findLtpc(feedBytes);
      if (ltpc == null) continue;

      output.add(
        DecodedTickCandidate(
          instrumentKey: instrument,
          ltp: ltpc.ltp,
          lttMs: ltpc.lttMs,
          ltq: ltpc.ltq,
          closePrice: ltpc.closePrice,
        ),
      );
    }

    return output;
  }

  _Ltpc? _findLtpc(Uint8List feed) {
    // Feed.oneof:
    // field 1 = ltpc
    // field 2 = full feed
    // field 3 = option chain.
    for (final field in readFields(feed)) {
      if (field.wireType != 2) continue;
      final nested = field.value as Uint8List;

      if (field.number == 1) {
        return _parseLtpc(nested);
      }

      if (field.number == 2) {
        // FullFeed: marketFF field 1 / indexFF field 2.
        for (final fullField in readFields(nested)) {
          if (fullField.wireType == 2 &&
              (fullField.number == 1 || fullField.number == 2)) {
            final full = fullField.value as Uint8List;
            for (final marketField in readFields(full)) {
              if (marketField.number == 1 && marketField.wireType == 2) {
                return _parseLtpc(marketField.value as Uint8List);
              }
            }
          }
        }
      }

      if (field.number == 3) {
        // OptionChain.ltpc is field 1.
        for (final optionField in readFields(nested)) {
          if (optionField.number == 1 && optionField.wireType == 2) {
            return _parseLtpc(optionField.value as Uint8List);
          }
        }
      }
    }
    return null;
  }

  _Ltpc? _parseLtpc(Uint8List bytes) {
    double? ltp;
    int? ltt;
    int? ltq;
    double? cp;

    for (final field in readFields(bytes)) {
      if (field.wireType == 1) {
        final raw = field.value as Uint8List;
        final value = decodeDouble(raw);
        if (field.number == 1) ltp = value;
        if (field.number == 4) cp = value;
      } else if (field.wireType == 0) {
        final value = field.value as int;
        if (field.number == 2) ltt = value;
        if (field.number == 3) ltq = value;
      }
    }

    if (ltp == null) return null;
    return _Ltpc(ltp: ltp, lttMs: ltt, ltq: ltq, closePrice: cp);
  }
}

class DecodedTickCandidate {
  final String instrumentKey;
  final double ltp;
  final int? lttMs;
  final int? ltq;
  final double? closePrice;

  const DecodedTickCandidate({
    required this.instrumentKey,
    required this.ltp,
    this.lttMs,
    this.ltq,
    this.closePrice,
  });
}

class _Ltpc {
  final double ltp;
  final int? lttMs;
  final int? ltq;
  final double? closePrice;

  const _Ltpc({
    required this.ltp,
    this.lttMs,
    this.ltq,
    this.closePrice,
  });
}
