import '../../../core/domain/models/market_models.dart';

class DecodedMarketTick {
  final MarketTick tick;
  final String feedType;
  final String instrumentKey;

  const DecodedMarketTick({
    required this.tick,
    required this.feedType,
    required this.instrumentKey,
  });
}
