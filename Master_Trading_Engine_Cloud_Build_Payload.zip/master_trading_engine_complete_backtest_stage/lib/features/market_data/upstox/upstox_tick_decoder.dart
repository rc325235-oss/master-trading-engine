import 'dart:typed_data';

import 'decoded_tick.dart';
import 'upstox_protobuf_decoder.dart';

/// Concrete integration boundary for generated FeedResponse.
///
/// The generated protobuf class is kept outside this handwritten layer.
/// Once `MarketDataFeed.pb.dart` is generated, this class should call
/// `FeedResponse.fromBuffer(bytes)` and map the selected feed's LTPC.
class UpstoxTickDecoder implements UpstoxProtobufDecoder<Object> {
  @override
  Object decode(Uint8List bytes) {
    if (bytes.isEmpty) {
      throw const FormatException('Empty Upstox feed message');
    }
    throw UnimplementedError(
      'Run protobuf generation and connect FeedResponse.fromBuffer(bytes).',
    );
  }
}
