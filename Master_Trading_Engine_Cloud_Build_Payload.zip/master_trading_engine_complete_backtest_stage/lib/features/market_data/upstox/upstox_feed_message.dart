class UpstoxLtpc {
  final double ltp;
  final int? ltt;
  final int? ltq;
  final double? cp;

  const UpstoxLtpc({
    required this.ltp,
    this.ltt,
    this.ltq,
    this.cp,
  });
}

class UpstoxFeedMessage {
  final String instrumentKey;
  final UpstoxLtpc ltpc;
  final int receivedAtMs;

  const UpstoxFeedMessage({
    required this.instrumentKey,
    required this.ltpc,
    required this.receivedAtMs,
  });
}
