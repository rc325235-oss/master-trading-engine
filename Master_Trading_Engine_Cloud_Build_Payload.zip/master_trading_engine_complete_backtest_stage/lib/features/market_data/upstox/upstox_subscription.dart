import 'dart:convert';
import 'dart:typed_data';

class UpstoxSubscription {
  final String guid;
  final String mode;
  final List<String> instrumentKeys;

  const UpstoxSubscription({
    required this.guid,
    required this.mode,
    required this.instrumentKeys,
  });

  Map<String, Object> toJson() => {
        'guid': guid,
        'method': 'sub',
        'data': {
          'mode': mode,
          'instrumentKeys': instrumentKeys,
        },
      };

  /// V3 expects the subscription request as a binary WebSocket message.
  /// The official feed uses a protobuf request format; this JSON helper is
  /// retained only for debugging/logging and is NOT sent to the live feed.
  Uint8List debugJsonBytes() =>
      Uint8List.fromList(utf8.encode(jsonEncode(toJson())));
}
