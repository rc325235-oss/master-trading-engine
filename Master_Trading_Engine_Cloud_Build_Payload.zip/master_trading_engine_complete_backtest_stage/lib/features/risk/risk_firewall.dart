import '../../core/domain/trading_signal.dart';

class RiskDecision {
  final bool allowed;
  final List<String> reasons;

  const RiskDecision({
    required this.allowed,
    required this.reasons,
  });
}

class RiskFirewall {
  final double minimumScore;
  final double maxScore;

  const RiskFirewall({
    this.minimumScore = 70,
    this.maxScore = 100,
  });

  RiskDecision check({
    required double score,
    required bool marketDataHealthy,
    required bool strategyEnabled,
  }) {
    if (!marketDataHealthy) {
      return const RiskDecision(
        allowed: false,
        reasons: ['MARKET_DATA_UNHEALTHY'],
      );
    }
    if (!strategyEnabled) {
      return const RiskDecision(
        allowed: false,
        reasons: ['STRATEGY_DISABLED'],
      );
    }
    if (score < minimumScore) {
      return RiskDecision(
        allowed: false,
        reasons: ['SCORE_BELOW_THRESHOLD'],
      );
    }
    if (score > maxScore) {
      return RiskDecision(
        allowed: false,
        reasons: ['SCORE_OUT_OF_RANGE'],
      );
    }
    return const RiskDecision(allowed: true, reasons: ['RISK_CHECK_PASSED']);
  }
}
