abstract interface class BrokerAdapter {
  Future<String> previewOrder({
    required String symbol,
    required String side,
    required int quantity,
  });

  Future<String> placeOrder({
    required String symbol,
    required String side,
    required int quantity,
  });
}

/// Production broker implementations must enforce the ExecutionGate,
/// Risk Firewall, HealthGate and KillSwitch before placing an order.
class DisabledBrokerAdapter implements BrokerAdapter {
  @override
  Future<String> previewOrder({
    required String symbol,
    required String side,
    required int quantity,
  }) async =>
      'ORDER_PREVIEW_ONLY';

  @override
  Future<String> placeOrder({
    required String symbol,
    required String side,
    required int quantity,
  }) async =>
      'REAL_ORDER_DISABLED';
}
