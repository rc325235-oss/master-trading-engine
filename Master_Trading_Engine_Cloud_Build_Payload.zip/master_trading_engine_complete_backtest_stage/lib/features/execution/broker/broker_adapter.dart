abstract class BrokerAdapter {
  Future<String> placeOrder({
    required String symbol,
    required String side,
    required double quantity,
    required double price,
  });

  Future<void> cancelOrder(String orderId);

  Future<String> getOrderStatus(String orderId);
}
