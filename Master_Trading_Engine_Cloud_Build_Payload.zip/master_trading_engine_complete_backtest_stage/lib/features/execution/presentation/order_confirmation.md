# Order Confirmation

⚠️ CONFIRM TRADE

Symbol:
Strategy:
Direction:
Score:

Quantity:
Entry:
Stop Loss:
T1:
T2:
Net R:R:
Estimated Charges/Slippage:

WHY THIS TRADE?
WHAT CAN GO WRONG?
WHAT CANCELS THIS TRADE?

Buttons:
[ CONFIRM ORDER ]
[ CANCEL ]

Before submission:
- Re-run risk firewall
- Re-check price
- Re-check quantity
- Re-check signal validity
- Check kill switch
