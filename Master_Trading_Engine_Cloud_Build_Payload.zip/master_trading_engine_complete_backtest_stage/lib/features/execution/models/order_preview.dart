class OrderPreview {
  final String symbol;
  final String side;
  final double quantity;
  final double entry;
  final double stopLoss;
  final double target1;
  final double target2;
  final double netRR;
  final double estimatedCosts;
  final String strategy;
  final double score;

  const OrderPreview({
    required this.symbol,
    required this.side,
    required this.quantity,
    required this.entry,
    required this.stopLoss,
    required this.target1,
    required this.target2,
    required this.netRR,
    required this.estimatedCosts,
    required this.strategy,
    required this.score,
  });
}
