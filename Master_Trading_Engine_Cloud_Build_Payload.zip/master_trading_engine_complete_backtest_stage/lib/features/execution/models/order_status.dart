enum OrderStatus {
  preview,
  awaitingConfirmation,
  submitted,
  accepted,
  rejected,
  partiallyFilled,
  filled,
  cancelled,
  failed,
}
