enum ExecutionDecision {
  blocked,
  confirmationRequired,
  allowed,
}

class ExecutionGate {
  ExecutionDecision evaluate({
    required bool riskPassed,
    required bool killSwitchOff,
    required bool userConfirmationRequired,
    required bool liveModeEnabled,
  }) {
    if (!riskPassed || !killSwitchOff) return ExecutionDecision.blocked;
    if (userConfirmationRequired || !liveModeEnabled) {
      return ExecutionDecision.confirmationRequired;
    }
    return ExecutionDecision.allowed;
  }
}
