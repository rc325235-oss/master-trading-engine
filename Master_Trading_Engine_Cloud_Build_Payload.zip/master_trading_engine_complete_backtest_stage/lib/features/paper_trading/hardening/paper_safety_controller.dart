import '../../../core/hardening/audit_log.dart';
import '../../../core/hardening/paper_session.dart';
import '../../../core/hardening/risk_limits.dart';

class PaperSafetyController {
  final RiskLimitGuard riskGuard;
  final PaperSessionController session;
  final AuditLog audit;
  bool _killSwitch = false;

  PaperSafetyController({required double startingEquity, RiskLimits limits = const RiskLimits(), AuditLog? auditLog})
      : riskGuard = RiskLimitGuard(limits: limits, startingEquity: startingEquity), session = PaperSessionController(), audit = auditLog ?? AuditLog();

  bool get killSwitchEnabled => _killSwitch;
  bool get canProcessTicks => !_killSwitch && session.canProcessTicks;

  void start() { if (_killSwitch) return; session.start(); audit.add('SESSION_START', 'Paper session started'); }
  void pause() { session.pause(); audit.add('SESSION_PAUSE', 'Paper session paused'); }
  void resume() { if (!_killSwitch) { session.resume(); audit.add('SESSION_RESUME', 'Paper session resumed'); } }
  void stop() { session.stop(); audit.add('SESSION_STOP', 'Paper session stopped'); }
  void kill(String reason) { _killSwitch = true; session.halt(reason); audit.add('KILL_SWITCH', reason); }
  void resetKillSwitch() { _killSwitch = false; session.stop(); audit.add('KILL_SWITCH_RESET', 'Kill switch reset; session remains stopped'); }

  RiskLimitResult authorizeTrade({required double equity, required double exposure, required double risk}) {
    if (_killSwitch) return const RiskLimitResult.rejected('KILL_SWITCH');
    if (!session.canProcessTicks) return const RiskLimitResult.rejected('SESSION_NOT_RUNNING');
    final result = riskGuard.check(equity: equity, proposedExposure: exposure, proposedRisk: risk);
    if (!result.allowed) audit.add('RISK_REJECT', result.reason!);
    return result;
  }

  void recordTrade(double realizedPnl, double exposure) => riskGuard.recordTrade(realizedPnl: realizedPnl, exposure: exposure);
}
