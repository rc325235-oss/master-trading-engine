enum PaperPositionStatus { pending, active, partial, closed, cancelled }

class PaperPosition {
  final String id;
  final String symbol;
  final String strategy;
  final String direction;
  final double entry;
  final double stopLoss;
  final double target1;
  final double target2;
  final double quantity;
  final double score;
  final DateTime openedAt;
  final PaperPositionStatus status;

  const PaperPosition({
    required this.id,
    required this.symbol,
    required this.strategy,
    required this.direction,
    required this.entry,
    required this.stopLoss,
    required this.target1,
    required this.target2,
    required this.quantity,
    required this.score,
    required this.openedAt,
    required this.status,
  });
}
