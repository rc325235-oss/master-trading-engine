import 'paper_order.dart';

enum PaperTradeDirection { long, short }

class PaperTrade {
  final String id;
  final String symbol;
  final PaperTradeDirection direction;
  final double quantity;
  final double entryPrice;
  final double exitPrice;
  final double grossPnl;
  final double fees;
  final double netPnl;
  final DateTime entryTime;
  final DateTime exitTime;
  final PaperExitReason exitReason;
  final double score;

  const PaperTrade({
    required this.id,
    required this.symbol,
    required this.direction,
    required this.quantity,
    required this.entryPrice,
    required this.exitPrice,
    required this.grossPnl,
    required this.fees,
    required this.netPnl,
    required this.entryTime,
    required this.exitTime,
    required this.exitReason,
    required this.score,
  });
}
