enum PaperOrderSide { buy, sell }
enum PaperOrderStatus { filled, rejected, cancelled }

enum PaperExitReason { stopLoss, target, reversal, manual, endOfSession }

class PaperOrder {
  final String id;
  final String symbol;
  final PaperOrderSide side;
  final double quantity;
  final double requestedPrice;
  final double fillPrice;
  final double fees;
  final DateTime timestamp;
  final PaperOrderStatus status;
  final String reason;

  const PaperOrder({
    required this.id,
    required this.symbol,
    required this.side,
    required this.quantity,
    required this.requestedPrice,
    required this.fillPrice,
    required this.fees,
    required this.timestamp,
    required this.status,
    required this.reason,
  });
}
