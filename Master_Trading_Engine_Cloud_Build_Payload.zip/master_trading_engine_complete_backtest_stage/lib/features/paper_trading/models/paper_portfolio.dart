import 'paper_order.dart';
import 'paper_trade.dart';

class PaperPortfolioSnapshot {
  final DateTime timestamp;
  final double cash;
  final double equity;
  final double unrealizedPnl;
  final double realizedPnl;
  final double drawdown;
  const PaperPortfolioSnapshot({required this.timestamp,required this.cash,required this.equity,required this.unrealizedPnl,required this.realizedPnl,required this.drawdown});
}

class PaperTradingReport {
  final double initialCapital;
  final double finalEquity;
  final double realizedPnl;
  final double unrealizedPnl;
  final double totalFees;
  final double maxDrawdown;
  final List<PaperTrade> trades;
  final List<PaperOrder> orders;
  final List<PaperPortfolioSnapshot> equityCurve;

  const PaperTradingReport({required this.initialCapital,required this.finalEquity,required this.realizedPnl,required this.unrealizedPnl,required this.totalFees,required this.maxDrawdown,required this.trades,required this.orders,required this.equityCurve});

  int get winningTrades => trades.where((t)=>t.netPnl>0).length;
  int get losingTrades => trades.where((t)=>t.netPnl<0).length;
  double get winRate => trades.isEmpty ? 0 : winningTrades / trades.length * 100;
  double get grossProfit => trades.where((t)=>t.netPnl>0).fold(0.0,(a,t)=>a+t.netPnl);
  double get grossLoss => trades.where((t)=>t.netPnl<0).fold(0.0,(a,t)=>a+t.netPnl.abs());
  double get profitFactor => grossLoss==0 ? double.infinity : grossProfit/grossLoss;
}
