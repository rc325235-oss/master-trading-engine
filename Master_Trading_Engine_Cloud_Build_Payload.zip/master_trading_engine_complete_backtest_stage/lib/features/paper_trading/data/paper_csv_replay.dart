import '../../backtest/backtest_models.dart';
import '../../../core/domain/models/market_models.dart';

class PaperCsvReplay {
  final List<HistoricalBar> bars;
  const PaperCsvReplay(this.bars);
  Iterable<MarketTick> get ticks sync* { for(final b in bars) yield MarketTick(symbol:'NIFTY',price:b.close,timestamp:b.timestamp); }
}
