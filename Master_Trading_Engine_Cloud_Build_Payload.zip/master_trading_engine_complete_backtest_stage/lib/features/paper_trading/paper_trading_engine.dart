import '../../core/domain/models/market_models.dart';
import '../risk/risk_firewall.dart';
import '../strategy/momentum_strategy.dart';
import '../strategy/strategy_models.dart';
import 'models/paper_order.dart';
import 'models/paper_portfolio.dart';
import 'models/paper_position.dart';
import 'models/paper_trade.dart';

class PaperTradingConfig {
  final double initialCapital;
  final double quantity;
  final double minimumScore;
  final double stopLossPercent;
  final double targetPercent;
  final double brokeragePerOrder;
  final double feeRate;
  final double slippageBps;
  final double maxPositionValuePercent;

  const PaperTradingConfig({this.initialCapital=100000,this.quantity=1,this.minimumScore=20,this.stopLossPercent=.01,this.targetPercent=.02,this.brokeragePerOrder=20,this.feeRate=.0005,this.slippageBps=2,this.maxPositionValuePercent=100});
}

class _OpenPosition {
  final String id; final String symbol; final PaperTradeDirection direction; final double qty; final double entry; final double stop; final double target; final DateTime time; final double score; final double entryFees;
  const _OpenPosition({required this.id,required this.symbol,required this.direction,required this.qty,required this.entry,required this.stop,required this.target,required this.time,required this.score,required this.entryFees});
}

class PaperTradingEngine {
  final PaperTradingConfig config;
  final MomentumStrategy strategy;
  final RiskFirewall firewall;
  double _cash;
  double _realized=0; double _fees=0; double _peak; double _lastEquity;
  _OpenPosition? _position;
  final List<PaperTrade> _trades=[]; final List<PaperOrder> _orders=[]; final List<PaperPortfolioSnapshot> _curve=[];
  final List<double> _prices=[];
  PaperTradingEngine({this.config=const PaperTradingConfig(), MomentumStrategy? strategy}) : strategy=strategy??MomentumStrategy(), firewall=RiskFirewall(minimumScore: config.minimumScore), _cash=config.initialCapital, _peak=config.initialCapital, _lastEquity=config.initialCapital;

  List<PaperTrade> get trades=>List.unmodifiable(_trades); List<PaperOrder> get orders=>List.unmodifiable(_orders); List<PaperPortfolioSnapshot> get equityCurve=>List.unmodifiable(_curve); PaperPosition? get activePosition=>_position==null?null:_toPublic(_position!); double get cash=>_cash;

  void reset(){_cash=config.initialCapital;_realized=0;_fees=0;_peak=config.initialCapital;_lastEquity=config.initialCapital;_position=null;_trades.clear();_orders.clear();_curve.clear();_prices.clear();}

  void onTick(MarketTick tick){
    if(tick.isStale || !tick.price.isFinite || tick.price<=0) return;
    _prices.add(tick.price); if(_prices.length>100) _prices.removeAt(0);
    if(_position!=null){
      final p=_position!;
      if(_hitExit(p,tick)){ _recordExit(tick, _exitFor(p,tick)); }
    }
    if(_position==null && _prices.length>=3){
      final d=strategy.evaluate(StrategyContext(tick:tick,recentPrices:List.unmodifiable(_prices)));
      final risk=firewall.check(score:d.score,marketDataHealthy:true,strategyEnabled:true);
      if(risk.allowed){
        final dir=d.reasons.contains('UP_MOMENTUM')?PaperTradeDirection.long: d.reasons.contains('DOWN_MOMENTUM')?PaperTradeDirection.short: null;
        if(dir!=null) _open(tick,dir,d.score);
      }
    }
    _snapshot(tick);
  }

  void closeAtMarket(MarketTick tick,{PaperExitReason reason=PaperExitReason.manual}){if(_position!=null)_recordExit(tick,reason);_snapshot(tick);}

  PaperTradingReport report(){final unreal=_position==null?0:_unrealized(_position!,_lastPrice()); return PaperTradingReport(initialCapital:config.initialCapital,finalEquity:_lastEquity,realizedPnl:_realized,unrealizedPnl:unreal,totalFees:_fees,maxDrawdown:_curve.isEmpty?0:_curve.map((e)=>e.drawdown).reduce((a,b)=>a>b?a:b),trades:List.unmodifiable(_trades),orders:List.unmodifiable(_orders),equityCurve:List.unmodifiable(_curve));}

  void finish(MarketTick last){if(_position!=null)_recordExit(last,PaperExitReason.endOfSession);_snapshot(last);}
  double _lastPrice()=>_prices.isEmpty?0:_prices.last;
  bool _hitExit(_OpenPosition p,MarketTick t)=>p.direction==PaperTradeDirection.long?(t.price<=p.stop||t.price>=p.target):(t.price>=p.stop||t.price<=p.target);
  PaperExitReason _exitFor(_OpenPosition p,MarketTick t){if(p.direction==PaperTradeDirection.long){if(t.price<=p.stop)return PaperExitReason.stopLoss;if(t.price>=p.target)return PaperExitReason.target;}else{if(t.price>=p.stop)return PaperExitReason.stopLoss;if(t.price<=p.target)return PaperExitReason.target;}return PaperExitReason.manual;}
  void _open(MarketTick t,PaperTradeDirection dir,double score){final fill=_slipped(t.price,dir==PaperTradeDirection.long?PaperOrderSide.buy:PaperOrderSide.sell); final notional=fill*config.quantity; final max=config.initialCapital*config.maxPositionValuePercent/100; if(notional>max || notional>_cash && dir==PaperTradeDirection.long)return; final fees=_feesFor(notional); _cash-=dir==PaperTradeDirection.long?notional+fees:fees; if(dir==PaperTradeDirection.short)_cash+=notional; _fees+=fees; final stop=dir==PaperTradeDirection.long?fill*(1-config.stopLossPercent):fill*(1+config.stopLossPercent); final target=dir==PaperTradeDirection.long?fill*(1+config.targetPercent):fill*(1-config.targetPercent); final id='P${DateTime.now().microsecondsSinceEpoch}'; _position=_OpenPosition(id:id,symbol:t.symbol,direction:dir,qty:config.quantity,entry:fill,stop:stop,target:target,time:t.timestamp,score:score,entryFees:fees); _orders.add(PaperOrder(id:'O${DateTime.now().microsecondsSinceEpoch}',symbol:t.symbol,side:dir==PaperTradeDirection.long?PaperOrderSide.buy:PaperOrderSide.sell,quantity:config.quantity,requestedPrice:t.price,fillPrice:fill,fees:fees,timestamp:t.timestamp,status:PaperOrderStatus.filled,reason:'PAPER_ENTRY'));}
  void _recordExit(MarketTick t,PaperExitReason reason){final p=_position!; final side=p.direction==PaperTradeDirection.long?PaperOrderSide.sell:PaperOrderSide.buy; final fill=_slipped(t.price,side); final gross=p.direction==PaperTradeDirection.long?(fill-p.entry)*p.qty:(p.entry-fill)*p.qty; final fees=_feesFor(fill*p.qty); final net=gross-p.entryFees-fees; _cash += p.direction==PaperTradeDirection.long?fill*p.qty-fees: -fill*p.qty-fees; _realized+=net; _fees+=fees; _trades.add(PaperTrade(id:p.id,symbol:p.symbol,direction:p.direction,quantity:p.qty,entryPrice:p.entry,exitPrice:fill,grossPnl:gross,fees:p.entryFees+fees,netPnl:net,entryTime:p.time,exitTime:t.timestamp,exitReason:reason,score:p.score)); _orders.add(PaperOrder(id:'O${DateTime.now().microsecondsSinceEpoch}',symbol:p.symbol,side:side,quantity:p.qty,requestedPrice:t.price,fillPrice:fill,fees:fees,timestamp:t.timestamp,status:PaperOrderStatus.filled,reason:'PAPER_EXIT_${reason.name.toUpperCase()}')); _position=null;}
  double _unrealized(_OpenPosition p,double price)=>p.direction==PaperTradeDirection.long?(price-p.entry)*p.qty:(p.entry-price)*p.qty;
  void _snapshot(MarketTick t){final unreal=_position==null?0:_unrealized(_position!,t.price); final positionValue=_position==null?0:(_position!.direction==PaperTradeDirection.long?t.price*_position!.qty:-t.price*_position!.qty); final equity=_cash+positionValue; if(equity>_peak)_peak=equity; final dd=_peak-equity; _lastEquity=equity; _curve.add(PaperPortfolioSnapshot(timestamp:t.timestamp,cash:_cash,equity:equity,unrealizedPnl:unreal,realizedPnl:_realized,drawdown:dd));}
  double _feesFor(double notional)=>config.brokeragePerOrder+notional*config.feeRate;
  double _slipped(double price,PaperOrderSide side)=>price*(1+(side==PaperOrderSide.buy?1:-1)*config.slippageBps/10000);
  static PaperPosition _toPublic(_OpenPosition p)=>PaperPosition(id:p.id,symbol:p.symbol,strategy:'momentum_v1',direction:p.direction==PaperTradeDirection.long?'LONG':'SHORT',entry:p.entry,stopLoss:p.stop,target1:p.target,target2:p.target,quantity:p.qty,score:p.score,openedAt:p.time,status:PaperPositionStatus.active);
}
