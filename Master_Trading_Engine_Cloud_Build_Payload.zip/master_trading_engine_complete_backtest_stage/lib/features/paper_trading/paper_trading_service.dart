import '../../core/domain/models/market_models.dart';
import 'paper_trading_engine.dart';
import 'models/paper_portfolio.dart';

class PaperTradingService {
  final PaperTradingEngine engine;
  bool _running=false;
  PaperTradingService({PaperTradingConfig config=const PaperTradingConfig()}) : engine=PaperTradingEngine(config:config);
  bool get isRunning=>_running;
  void start(){_running=true;}
  void pause(){_running=false;}
  void reset(){_running=false;engine.reset();}
  void process(MarketTick tick){if(_running)engine.onTick(tick);}
  void close(MarketTick tick){engine.closeAtMarket(tick);}
  void finish(MarketTick tick){engine.finish(tick);_running=false;}
  PaperTradingReport get report=>engine.report();
}
