class AlertRules {
  static const double minimumScore = 70.0;
  static const double aPlusScore = 90.0;
  static const bool manualConfirmationRequired = true;
  static const bool realOrderPlacement = false;
}
