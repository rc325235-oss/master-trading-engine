// Phase integration point: manual_alerts
