enum AlertType { tradeReady, entryTriggered, stopLoss, target, invalidated, risk, dataIssue }

class LiveAlert {
  final String id;
  final String symbol;
  final AlertType type;
  final String message;
  final DateTime timestamp;
  final double? entry;
  final double? stopLoss;
  final List<double> targets;
  final double score;

  const LiveAlert({
    required this.id,
    required this.symbol,
    required this.type,
    required this.message,
    required this.timestamp,
    required this.score,
    this.entry,
    this.stopLoss,
    this.targets = const [],
  });
}
