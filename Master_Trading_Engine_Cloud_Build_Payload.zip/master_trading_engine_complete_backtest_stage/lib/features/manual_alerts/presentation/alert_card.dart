import 'package:flutter/material.dart';
import '../models/live_alert.dart';

class AlertCard extends StatelessWidget {
  final LiveAlert alert;
  const AlertCard({super.key, required this.alert});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        title: Text('${alert.symbol} • ${alert.type.name}'),
        subtitle: Text(alert.message),
        trailing: Text(alert.score.toStringAsFixed(0)),
      ),
    );
  }
}
