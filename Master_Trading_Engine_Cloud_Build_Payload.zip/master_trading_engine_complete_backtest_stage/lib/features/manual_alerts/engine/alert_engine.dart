import '../models/live_alert.dart';

class AlertEngine {
  LiveAlert? createTradeReady({
    required String symbol,
    required double score,
    required String message,
    double? entry,
    double? stopLoss,
    List<double> targets = const [],
  }) {
    if (score < 70) return null;
    return LiveAlert(
      id: '${symbol}_${DateTime.now().microsecondsSinceEpoch}',
      symbol: symbol,
      type: AlertType.tradeReady,
      message: message,
      timestamp: DateTime.now(),
      score: score,
      entry: entry,
      stopLoss: stopLoss,
      targets: targets,
    );
  }
}
