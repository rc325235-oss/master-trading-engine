// Phase integration point: strategies
