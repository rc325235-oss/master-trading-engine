import '../../core/domain/models/market_models.dart';
import '../../core/domain/models/trade_models.dart';
import '../../core/engine/trading_engine.dart';

class BasicSignalEngine implements SignalEngine {
  @override
  TradeSignal generate(MarketTick tick) {
    return TradeSignal(
      symbol: tick.symbol,
      direction: TradeDirection.flat,
      score: 0,
      reason: 'Development signal: real Phase 2 engine not connected yet',
    );
  }
}
