import '../backtest/backtest_models.dart';

class CsvImportResult {
  final List<HistoricalBar> bars;
  final List<String> warnings;
  final int duplicateRows;
  final int invalidRows;

  const CsvImportResult({
    required this.bars,
    required this.warnings,
    this.duplicateRows = 0,
    this.invalidRows = 0,
  });
}

class CsvHistoricalDataProvider {
  const CsvHistoricalDataProvider();

  CsvImportResult parse(String csv) {
    final lines = csv.split(RegExp(r'\r?\n')).map((e) => e.trim()).where((e) => e.isNotEmpty).toList();
    if (lines.length < 2) throw const FormatException('CSV must contain a header and at least one data row.');
    final header = _parseRow(lines.first).map(_normalize).toList();
    final ti = _find(header, ['timestamp', 'datetime', 'date', 'time']);
    final oi = _find(header, ['open', 'o']);
    final hi = _find(header, ['high', 'h']);
    final li = _find(header, ['low', 'l']);
    final ci = _find(header, ['close', 'c', 'ltp', 'price']);
    final vi = _find(header, ['volume', 'vol', 'v']);
    if ([ti, oi, hi, li, ci].contains(-1)) {
      throw const FormatException('Required columns: timestamp, open, high, low, close. Volume is optional.');
    }

    final bars = <HistoricalBar>[];
    final warnings = <String>[];
    var invalid = 0;
    for (var lineNumber = 2; lineNumber <= lines.length; lineNumber++) {
      try {
        final row = _parseRow(lines[lineNumber - 1]);
        final timestamp = _parseTimestamp(_cell(row, ti));
        final open = _number(_cell(row, oi));
        final high = _number(_cell(row, hi));
        final low = _number(_cell(row, li));
        final close = _number(_cell(row, ci));
        final volume = vi == -1 ? 0.0 : _number(_cell(row, vi));
        if ([open, high, low, close].any((v) => v <= 0) || high < low || open > high || open < low || close > high || close < low || volume < 0) {
          throw const FormatException('Invalid OHLC/volume values.');
        }
        bars.add(HistoricalBar(timestamp: timestamp, open: open, high: high, low: low, close: close, volume: volume));
      } catch (e) {
        invalid++;
        warnings.add('Line $lineNumber skipped: $e');
      }
    }
    bars.sort((a, b) => a.timestamp.compareTo(b.timestamp));
    final deduped = <HistoricalBar>[];
    final seen = <DateTime>{};
    var duplicates = 0;
    for (final bar in bars) {
      final key = bar.timestamp.toUtc();
      if (!seen.add(key)) {
        duplicates++;
        warnings.add('Duplicate timestamp removed: ${bar.timestamp.toIso8601String()}');
        continue;
      }
      deduped.add(bar);
    }
    if (deduped.isEmpty) throw const FormatException('No valid OHLC rows were found.');
    return CsvImportResult(bars: deduped, warnings: warnings, duplicateRows: duplicates, invalidRows: invalid);
  }

  DateTime _parseTimestamp(String value) {
    final raw = value.trim();
    final parsed = DateTime.tryParse(raw) ?? DateTime.tryParse(raw.replaceFirst(' ', 'T'));
    if (parsed == null) throw FormatException('Invalid timestamp: $value');
    return parsed;
  }

  List<String> _parseRow(String line) {
    final result = <String>[]; final buffer = StringBuffer(); var quoted = false;
    for (var i = 0; i < line.length; i++) {
      final char = line[i];
      if (char == '"') {
        if (quoted && i + 1 < line.length && line[i + 1] == '"') { buffer.write('"'); i++; }
        else { quoted = !quoted; }
      } else if (char == ',' && !quoted) { result.add(buffer.toString().trim()); buffer.clear(); }
      else { buffer.write(char); }
    }
    result.add(buffer.toString().trim()); return result;
  }
  String _normalize(String value) => value.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');
  int _find(List<String> header, List<String> aliases) { for (final a in aliases) { final i = header.indexOf(_normalize(a)); if (i != -1) return i; } return -1; }
  String _cell(List<String> row, int index) { if (index < 0 || index >= row.length) throw const FormatException('Missing column value.'); return row[index].trim(); }
  double _number(String value) { final p = double.tryParse(value.replaceAll(',', '')); if (p == null || !p.isFinite) throw FormatException('Not a number: $value'); return p; }
}
