// Phase integration point: scanner
