import 'package:flutter/material.dart';
import '../../core/auth/auth_service.dart';
import '../../core/sync/cloud_sync_service.dart';
import '../../core/notifications/notification_center.dart';

class AccountSyncScreen extends StatefulWidget { const AccountSyncScreen({super.key}); @override State<AccountSyncScreen> createState()=>_AccountSyncScreenState(); }
class _AccountSyncScreenState extends State<AccountSyncScreen>{
  final _auth=LocalAuthService(); final _user=TextEditingController(text:'demo-user'); final _name=TextEditingController(text:'Paper Trader');
  AuthSession? _session; SyncStatus? _status; final _notifications=NotificationCenter();
  @override void initState(){super.initState();_restore();}
  Future<void> _restore() async { final s=await _auth.restore(); if(mounted)setState(()=>_session=s); }
  Future<void> _login() async { if(_user.text.trim().isEmpty)return; final s=await _auth.signIn(_user.text,_name.text); if(mounted){setState(()=>_session=s);_notifications.publish('Signed in','Local authenticated session restored.');}}
  Future<void> _logout() async { await _auth.signOut(); if(mounted)setState(()=>_session=null); }
  Future<void> _sync() async { final s=_session; if(s==null)return; final service=PaperCloudSyncService(); final status=await service.sync(s.userId,{'schemaVersion':1,'updatedAt':DateTime.now().toUtc().toIso8601String(),'paperMode':true}); if(mounted)setState(()=>_status=status); }
  @override void dispose(){_user.dispose();_name.dispose();super.dispose();}
  @override Widget build(BuildContext context)=>ListView(padding:const EdgeInsets.all(16),children:[Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[Text('Account & Cloud Sync',style:Theme.of(context).textTheme.headlineSmall),const SizedBox(height:12),if(_session==null)...[TextField(controller:_user,decoration:const InputDecoration(labelText:'User ID',border:OutlineInputBorder())),const SizedBox(height:10),TextField(controller:_name,decoration:const InputDecoration(labelText:'Display Name',border:OutlineInputBorder())),const SizedBox(height:10),FilledButton.icon(onPressed:_login,icon:const Icon(Icons.login),label:const Text('Sign In'))]else...[_info('User',_session!.displayName),_info('User ID',_session!.userId),_info('Signed In',_session!.signedInAt.toLocal().toString()),Wrap(spacing:8,children:[FilledButton.icon(onPressed:_sync,icon:const Icon(Icons.cloud_upload),label:const Text('Sync')),OutlinedButton.icon(onPressed:_logout,icon:const Icon(Icons.logout),label:const Text('Sign Out'))])],if(_status!=null)Padding(padding:const EdgeInsets.only(top:12),child:Text(_status!.message))]))),const SizedBox(height:12),Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[Text('Security & Sync Policy',style:Theme.of(context).textTheme.titleLarge),const SizedBox(height:8),const Text('• Paper Trading remains simulation-only.\n• Local session is persisted on-device.\n• Cloud sync uses a provider adapter and offline queue.\n• Configure a trusted HTTPS backend before production cloud sync.\n• Do not put API keys or broker tokens in source code.\n• Real broker execution remains disabled.')]))) ]);
  Widget _info(String a,String b)=>Padding(padding:const EdgeInsets.only(bottom:8),child:Text('$a: $b'));
}
