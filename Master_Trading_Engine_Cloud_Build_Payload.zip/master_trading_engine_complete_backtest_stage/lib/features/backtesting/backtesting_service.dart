// Phase integration point: backtesting
