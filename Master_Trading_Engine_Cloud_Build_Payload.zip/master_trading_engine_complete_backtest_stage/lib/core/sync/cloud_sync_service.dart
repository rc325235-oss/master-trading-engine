import 'dart:convert';
import 'package:http/http.dart' as http;
import '../persistence/durable_paper_store.dart';

class SyncStatus { final bool online; final DateTime? lastSync; final String message; const SyncStatus({required this.online,this.lastSync,required this.message}); }

abstract class CloudSyncProvider {
  Future<void> push(String userId, Map<String,Object?> payload);
  Future<Map<String,dynamic>?> pull(String userId);
}

/// Generic REST adapter. Set an HTTPS endpoint in SyncConfig when a backend is available.
class RestCloudSyncProvider implements CloudSyncProvider {
  final Uri baseUri; final http.Client client; final String? bearerToken;
  RestCloudSyncProvider(this.baseUri,{http.Client? client,this.bearerToken}):client=client??http.Client();
  Map<String,String> get _headers=>{'content-type':'application/json',if(bearerToken!=null)'authorization':'Bearer $bearerToken'};
  @override Future<void> push(String userId,Map<String,Object?> payload) async { final r=await client.put(baseUri.resolve('/users/$userId/paper-state'),headers:_headers,body:jsonEncode(payload)); if(r.statusCode<200||r.statusCode>=300) throw Exception('Sync push failed: ${r.statusCode}'); }
  @override Future<Map<String,dynamic>?> pull(String userId) async { final r=await client.get(baseUri.resolve('/users/$userId/paper-state'),headers:_headers); if(r.statusCode==404)return null; if(r.statusCode<200||r.statusCode>=300)throw Exception('Sync pull failed: ${r.statusCode}'); return jsonDecode(r.body) as Map<String,dynamic>; }
}

class SyncQueue {
  final DurableJsonStore store=const DurableJsonStore('pending_sync.json');
  Future<void> enqueue(Map<String,Object?> payload)=>store.write({'queuedAt':DateTime.now().toUtc().toIso8601String(),'payload':payload});
  Future<Map<String,dynamic>?> peek()=>store.read();
  Future<void> clear()=>store.clear();
}

class PaperCloudSyncService {
  final CloudSyncProvider? provider; final SyncQueue queue;
  PaperCloudSyncService({this.provider,SyncQueue? queue}):queue=queue??SyncQueue();
  Future<SyncStatus> sync(String userId,Map<String,Object?> payload) async {
    if(provider==null){await queue.enqueue(payload);return SyncStatus(online:false,message:'Cloud provider not configured; saved to offline queue.');}
    try { await provider!.push(userId,payload); await queue.clear(); return SyncStatus(online:true,lastSync:DateTime.now().toUtc(),message:'Cloud sync successful.'); }
    catch(e){await queue.enqueue(payload);return SyncStatus(online:false,message:'Offline/error; queued locally.');}
  }
  Future<Map<String,dynamic>?> restore(String userId) async => provider?.pull(userId);
}
