enum PaperSessionStatus { stopped, starting, running, paused, halted }

class PaperSessionState {
  final PaperSessionStatus status;
  final DateTime? startedAt;
  final DateTime updatedAt;
  final String? haltReason;

  const PaperSessionState({this.status = PaperSessionStatus.stopped, this.startedAt, required this.updatedAt, this.haltReason});

  PaperSessionState copyWith({PaperSessionStatus? status, DateTime? startedAt, DateTime? updatedAt, String? haltReason}) =>
      PaperSessionState(status: status ?? this.status, startedAt: startedAt ?? this.startedAt, updatedAt: updatedAt ?? DateTime.now().toUtc(), haltReason: haltReason ?? this.haltReason);
}

class PaperSessionController {
  PaperSessionState _state = PaperSessionState(updatedAt: DateTime.now().toUtc());
  PaperSessionState get state => _state;
  bool get canProcessTicks => _state.status == PaperSessionStatus.running;

  void start() => _state = _state.copyWith(status: PaperSessionStatus.running, startedAt: DateTime.now().toUtc(), haltReason: null);
  void pause() => _state = _state.copyWith(status: PaperSessionStatus.paused);
  void resume() => _state = _state.copyWith(status: PaperSessionStatus.running);
  void stop() => _state = _state.copyWith(status: PaperSessionStatus.stopped);
  void halt(String reason) => _state = _state.copyWith(status: PaperSessionStatus.halted, haltReason: reason);
}
