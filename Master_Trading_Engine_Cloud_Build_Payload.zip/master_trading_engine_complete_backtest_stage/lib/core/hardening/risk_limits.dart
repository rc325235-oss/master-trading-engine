class RiskLimits {
  final double maxDailyLoss;
  final double maxPositionValuePercent;
  final int maxTradesPerDay;
  final double maxExposure;
  final double maxRiskPerTrade;

  const RiskLimits({
    this.maxDailyLoss = 0.02,
    this.maxPositionValuePercent = 0.25,
    this.maxTradesPerDay = 20,
    this.maxExposure = 1.0,
    this.maxRiskPerTrade = 0.01,
  });
}

class RiskLimitState {
  final DateTime sessionDate;
  final double startingEquity;
  final double realizedPnl;
  final int trades;
  final double exposure;

  const RiskLimitState({
    required this.sessionDate,
    required this.startingEquity,
    this.realizedPnl = 0,
    this.trades = 0,
    this.exposure = 0,
  });

  double get dailyLoss => realizedPnl < 0 ? -realizedPnl : 0;
}

class RiskLimitResult {
  final bool allowed;
  final String? reason;
  const RiskLimitResult.allowed() : allowed = true, reason = null;
  const RiskLimitResult.rejected(this.reason) : allowed = false;
}

class RiskLimitGuard {
  final RiskLimits limits;
  RiskLimitState state;

  RiskLimitGuard({this.limits = const RiskLimits(), required double startingEquity})
      : state = RiskLimitState(sessionDate: DateTime.now(), startingEquity: startingEquity);

  RiskLimitResult check({required double equity, required double proposedExposure, required double proposedRisk}) {
    _rollSession(equity);
    if (state.trades >= limits.maxTradesPerDay) return const RiskLimitResult.rejected('MAX_TRADES_PER_DAY');
    if (state.dailyLoss >= state.startingEquity * limits.maxDailyLoss) return const RiskLimitResult.rejected('DAILY_LOSS_LIMIT');
    if (proposedExposure > state.startingEquity * limits.maxPositionValuePercent) return const RiskLimitResult.rejected('POSITION_SIZE_LIMIT');
    if (state.exposure + proposedExposure > state.startingEquity * limits.maxExposure) return const RiskLimitResult.rejected('MAX_EXPOSURE');
    if (proposedRisk > state.startingEquity * limits.maxRiskPerTrade) return const RiskLimitResult.rejected('PER_TRADE_RISK_LIMIT');
    return const RiskLimitResult.allowed();
  }

  void recordTrade({required double realizedPnl, required double exposure}) {
    state = RiskLimitState(sessionDate: state.sessionDate, startingEquity: state.startingEquity,
      realizedPnl: state.realizedPnl + realizedPnl, trades: state.trades + 1, exposure: exposure);
  }

  void _rollSession(double equity) {
    final now = DateTime.now();
    if (now.year != state.sessionDate.year || now.month != state.sessionDate.month || now.day != state.sessionDate.day) {
      state = RiskLimitState(sessionDate: now, startingEquity: equity);
    }
  }
}
