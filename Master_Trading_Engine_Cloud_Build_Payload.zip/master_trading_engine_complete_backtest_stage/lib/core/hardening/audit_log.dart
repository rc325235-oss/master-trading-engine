class AuditEvent {
  final DateTime timestamp;
  final String type;
  final String message;
  final Map<String, Object?> data;
  const AuditEvent({required this.timestamp, required this.type, required this.message, this.data = const {}});

  Map<String, Object?> toJson() => {'timestamp': timestamp.toIso8601String(), 'type': type, 'message': message, 'data': data};
}

class AuditLog {
  final List<AuditEvent> _events = [];
  List<AuditEvent> get events => List.unmodifiable(_events);

  void add(String type, String message, [Map<String, Object?> data = const {}]) {
    _events.add(AuditEvent(timestamp: DateTime.now().toUtc(), type: type, message: message, data: data));
  }

  void clear() => _events.clear();
}
