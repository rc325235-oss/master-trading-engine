import 'dart:convert';

class PaperStateSnapshot {
  final DateTime savedAt;
  final double cash;
  final double equity;
  final int orders;
  final int trades;
  final String sessionStatus;

  const PaperStateSnapshot({required this.savedAt, required this.cash, required this.equity, required this.orders, required this.trades, required this.sessionStatus});

  Map<String, Object?> toJson() => {'savedAt': savedAt.toIso8601String(), 'cash': cash, 'equity': equity, 'orders': orders, 'trades': trades, 'sessionStatus': sessionStatus};
  String encode() => jsonEncode(toJson());

  static PaperStateSnapshot decode(String source) {
    final m = jsonDecode(source) as Map<String, dynamic>;
    return PaperStateSnapshot(savedAt: DateTime.parse(m['savedAt'] as String), cash: (m['cash'] as num).toDouble(), equity: (m['equity'] as num).toDouble(), orders: m['orders'] as int, trades: m['trades'] as int, sessionStatus: m['sessionStatus'] as String);
  }
}

abstract class PaperStateStore {
  Future<void> save(PaperStateSnapshot snapshot);
  Future<PaperStateSnapshot?> load();
  Future<void> clear();
}

class MemoryPaperStateStore implements PaperStateStore {
  String? _value;
  @override Future<void> save(PaperStateSnapshot snapshot) async => _value = snapshot.encode();
  @override Future<PaperStateSnapshot?> load() async => _value == null ? null : PaperStateSnapshot.decode(_value!);
  @override Future<void> clear() async => _value = null;
}
