import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
import '../hardening/paper_state_snapshot.dart';

class DurablePaperStateStore implements PaperStateStore {
  static const _fileName = 'paper_state_snapshot.json';
  Future<File> _file() async {
    final dir = await getApplicationDocumentsDirectory();
    return File('${dir.path}/$_fileName');
  }
  @override
  Future<void> save(PaperStateSnapshot snapshot) async {
    final file = await _file();
    await file.writeAsString(snapshot.encode(), flush: true);
  }
  @override
  Future<PaperStateSnapshot?> load() async {
    try {
      final file = await _file();
      if (!await file.exists()) return null;
      return PaperStateSnapshot.decode(await file.readAsString());
    } catch (_) { return null; }
  }
  @override
  Future<void> clear() async { try { final f = await _file(); if (await f.exists()) await f.delete(); } catch (_) {} }
}

class DurableJsonStore {
  final String fileName;
  const DurableJsonStore(this.fileName);
  Future<File> _file() async {
    final dir = await getApplicationDocumentsDirectory();
    return File('${dir.path}/$fileName');
  }
  Future<void> write(Map<String, Object?> value) async => (await _file()).writeAsString(jsonEncode(value), flush: true);
  Future<Map<String, dynamic>?> read() async {
    try { final f = await _file(); if (!await f.exists()) return null; return jsonDecode(await f.readAsString()) as Map<String, dynamic>; } catch (_) { return null; }
  }
  Future<void> clear() async { try { final f = await _file(); if (await f.exists()) await f.delete(); } catch (_) {} }
}
