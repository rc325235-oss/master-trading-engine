enum ExecutionMode { backtest, paper, manualAlert, semiAuto, auto }
extension ExecutionModeSafety on ExecutionMode { bool get canPlaceRealOrders => this == ExecutionMode.auto; }
