class RiskDefaults {
  static const double maxRiskPerTradePercent = 1.0;
  static const double minimumScore = 70.0;
  static const double minimumRiskReward = 1.5;
}
