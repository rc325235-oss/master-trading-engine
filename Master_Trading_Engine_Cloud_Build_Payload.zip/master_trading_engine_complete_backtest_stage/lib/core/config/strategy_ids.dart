class StrategyIds {
  static const trendRider = 'trend_rider';
  static const breakoutHunter = 'breakout_hunter';
  static const meanReversion = 'mean_reversion';
}
