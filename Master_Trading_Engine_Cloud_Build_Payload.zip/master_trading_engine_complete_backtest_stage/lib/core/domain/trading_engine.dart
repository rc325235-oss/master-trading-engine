import 'models/market_models.dart';
import 'trading_signal.dart';
import '../../features/risk/risk_firewall.dart';
import '../../features/strategy/strategy_models.dart';

class TradingEngineConfig {
  final double minimumScore;
  final double staleSeconds;
  final bool strategyEnabled;

  const TradingEngineConfig({
    this.minimumScore = 70,
    this.staleSeconds = 5,
    this.strategyEnabled = false,
  });
}

class TradingEngineResult {
  final MarketTick tick;
  final TradingSignal signal;
  final bool riskAllowed;

  const TradingEngineResult({
    required this.tick,
    required this.signal,
    required this.riskAllowed,
  });
}

class TradingEngine {
  final TradingEngineConfig config;
  final Strategy strategy;
  final RiskFirewall riskFirewall;

  const TradingEngine({
    this.config = const TradingEngineConfig(),
    required this.strategy,
    RiskFirewall? riskFirewall,
  }) : riskFirewall = riskFirewall ?? const RiskFirewall();

  TradingEngineResult evaluate(
    MarketTick tick, {
    List<double> recentPrices = const [],
  }) {
    final age = DateTime.now().difference(tick.timestamp).inMilliseconds / 1000;
    final healthy = !tick.isStale && age <= config.staleSeconds;

    if (!healthy) {
      return _neutral(tick, ['STALE_MARKET_DATA']);
    }

    if (!config.strategyEnabled) {
      return _neutral(tick, ['STRATEGY_DISABLED']);
    }

    final decision = strategy.evaluate(
      StrategyContext(tick: tick, recentPrices: recentPrices),
    );

    final risk = riskFirewall.check(
      score: decision.score,
      marketDataHealthy: healthy,
      strategyEnabled: config.strategyEnabled,
    );

    final direction = risk.allowed
        ? (recentPrices.isNotEmpty && recentPrices.last > recentPrices.first
            ? SignalDirection.buy
            : SignalDirection.sell)
        : SignalDirection.neutral;

    return TradingEngineResult(
      tick: tick,
      signal: TradingSignal(
        direction: direction,
        score: decision.score,
        symbol: tick.symbol,
        timestamp: DateTime.now(),
        reasons: [...decision.reasons, ...risk.reasons],
      ),
      riskAllowed: risk.allowed,
    );
  }

  TradingEngineResult _neutral(MarketTick tick, List<String> reasons) {
    return TradingEngineResult(
      tick: tick,
      signal: TradingSignal(
        direction: SignalDirection.neutral,
        score: 0,
        symbol: tick.symbol,
        timestamp: DateTime.now(),
        reasons: reasons,
      ),
      riskAllowed: false,
    );
  }
}
