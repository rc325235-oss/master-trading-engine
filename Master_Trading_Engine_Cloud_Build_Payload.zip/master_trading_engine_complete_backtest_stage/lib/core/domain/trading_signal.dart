enum SignalDirection { buy, sell, neutral }

class TradingSignal {
  final SignalDirection direction;
  final double score;
  final String symbol;
  final DateTime timestamp;
  final List<String> reasons;

  const TradingSignal({
    required this.direction,
    required this.score,
    required this.symbol,
    required this.timestamp,
    required this.reasons,
  });
}
