import '../models/market_models.dart';
import '../models/trade_models.dart';
import '../models/risk_models.dart';

abstract interface class MarketDataEngine { Stream<MarketTick> get ticks; }
abstract interface class StrategyEngine { TradeSignal evaluate(MarketTick tick); }
abstract interface class RiskEngine { RiskDecision evaluate(TradeSignal signal); }
