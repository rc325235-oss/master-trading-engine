class MarketTick {
  final String symbol;
  final double price;
  final DateTime timestamp;
  final bool isStale;
  const MarketTick({required this.symbol, required this.price, required this.timestamp, this.isStale = false});
}
