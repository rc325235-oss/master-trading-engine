class RiskDecision {
  final bool allowed;
  final String reason;
  const RiskDecision({required this.allowed, required this.reason});
}
