enum TradeDirection { long, short, flat }
class TradeSignal {
  final String symbol;
  final TradeDirection direction;
  final double score;
  final String reason;
  const TradeSignal({required this.symbol, required this.direction, required this.score, required this.reason});
}
