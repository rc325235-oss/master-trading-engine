import '../domain/models/market_models.dart';
import '../domain/models/trade_models.dart';
import '../domain/models/risk_models.dart';

abstract interface class MarketDataSource {
  Future<MarketTick> getLatest(String symbol);
}

abstract interface class SignalEngine {
  TradeSignal generate(MarketTick tick);
}

class TradingDecision {
  final TradeSignal signal;
  final RiskDecision risk;

  const TradingDecision({required this.signal, required this.risk});

  bool get approved => risk.allowed;
}

class TradingEngine {
  final MarketDataSource marketData;
  final SignalEngine signalEngine;
  final RiskDecision Function(TradeSignal) riskCheck;

  const TradingEngine({
    required this.marketData,
    required this.signalEngine,
    required this.riskCheck,
  });

  Future<TradingDecision> evaluate(String symbol) async {
    final tick = await marketData.getLatest(symbol);
    final signal = signalEngine.generate(tick);
    final risk = riskCheck(signal);
    return TradingDecision(signal: signal, risk: risk);
  }
}
