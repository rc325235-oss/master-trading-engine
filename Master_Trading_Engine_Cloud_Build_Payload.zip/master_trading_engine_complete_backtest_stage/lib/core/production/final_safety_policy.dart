/// Final release safety policy.
///
/// This build is intentionally PAPER-ONLY. Real broker execution is disabled
/// until a separate, explicit live-trading release is created and audited.
class FinalSafetyPolicy {
  static const bool paperOnly = true;
  static const bool allowRealOrders = false;
  static const bool requireExplicitLiveRelease = true;

  static void assertPaperOnly() {
    if (!paperOnly || allowRealOrders) {
      throw StateError('Unsafe execution policy: final build must remain paper-only.');
    }
  }
}
