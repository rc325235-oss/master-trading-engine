class KillSwitch {
  bool _enabled = false;
  bool get enabled => _enabled;
  void enable() => _enabled = true;
  void disable() => _enabled = false;
}
