class HealthGate {
  bool isHealthy({required bool marketDataHealthy, required bool brokerHealthy, required bool riskEngineHealthy}) =>
      marketDataHealthy && brokerHealthy && riskEngineHealthy;
}
