import 'dart:convert';
import '../persistence/durable_paper_store.dart';

class AuthSession {
  final String userId;
  final String displayName;
  final DateTime signedInAt;
  const AuthSession({required this.userId, required this.displayName, required this.signedInAt});
  Map<String,Object?> toJson()=>{'userId':userId,'displayName':displayName,'signedInAt':signedInAt.toIso8601String()};
  factory AuthSession.fromJson(Map<String,dynamic> m)=>AuthSession(userId:m['userId'] as String,displayName:m['displayName'] as String,signedInAt:DateTime.parse(m['signedInAt'] as String));
}

abstract class AuthService {
  Future<AuthSession?> restore();
  Future<AuthSession> signIn(String userId, String displayName);
  Future<void> signOut();
}

class LocalAuthService implements AuthService {
  final DurableJsonStore _store = const DurableJsonStore('auth_session.json');
  @override Future<AuthSession?> restore() async { final m=await _store.read(); return m==null?null:AuthSession.fromJson(m); }
  @override Future<AuthSession> signIn(String userId,String displayName) async { final s=AuthSession(userId:userId.trim(),displayName:displayName.trim(),signedInAt:DateTime.now().toUtc()); await _store.write(s.toJson()); return s; }
  @override Future<void> signOut()=>_store.clear();
}

/// Production adapter contract. Connect Firebase/Auth0/custom backend here without changing the UI.
abstract class RemoteAuthProvider {
  Future<AuthSession> signIn(String userId, String credential);
  Future<void> signOut();
}

String encodeAuthSession(AuthSession s)=>jsonEncode(s.toJson());
