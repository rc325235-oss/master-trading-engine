class TradingNotification { final DateTime timestamp; final String title; final String message; final String severity; const TradingNotification({required this.timestamp,required this.title,required this.message,required this.severity}); }

class NotificationCenter {
  final List<TradingNotification> _items=[];
  List<TradingNotification> get items=>List.unmodifiable(_items);
  void publish(String title,String message,{String severity='info'}){_items.insert(0,TradingNotification(timestamp:DateTime.now().toUtc(),title:title,message:message,severity:severity)); if(_items.length>100)_items.removeLast();}
  void clear()=>_items.clear();
}

/// FCM/OS push adapter contract. The app remains provider-neutral until Firebase is configured.
abstract class PushNotificationProvider { Future<void> initialize(); Future<void> send(String title,String body); }
